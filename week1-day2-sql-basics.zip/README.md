
# Day 2 - Oracle SQL Basics

## What I Learned
- How to create tables with proper data types in Oracle SQL
- How to use SELECT queries with WHERE conditions
- Filtering data with AND, OR, and NOT
- Sorting and limiting results
- Updating specific rows in a table

## Table Used
**Table Name:** employees

## SQL Practice Highlights
1. Retrieve employees with salary > 4000 and not in IT
2. Find employees hired before Jan 2021
3. List all employees from HR or Finance
4. Display all employees sorted by salary (highest first)
5. Get top 3 highest paid employees
6. Update a specific employee's information

## Tools Used
- Oracle LiveSQL (https://livesql.oracle.com/)
