
-- Update employee with id = 3
UPDATE employees
SET name = 'Nadzirah Najihah Binti Hasnul Basri',
    salary = 4400.00,
    hire_date = TO_DATE('08-02-2024', 'DD-MM-YYYY')
WHERE id = 3;
