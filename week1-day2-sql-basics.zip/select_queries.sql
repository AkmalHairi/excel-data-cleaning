
-- Employees with salary > 4000 and not in IT
SELECT name, salary FROM employees
WHERE salary > 4000 AND department != 'IT';

-- Employees hired before Jan 1, 2021
SELECT name, hire_date FROM employees
WHERE hire_date < TO_DATE('2021-01-01', 'YYYY-MM-DD');

-- Employees from HR or Finance department
SELECT * FROM employees
WHERE department = 'HR' OR department = 'Finance';

-- All employees ordered by salary descending
SELECT * FROM employees
ORDER BY salary DESC;

-- Top 3 highest paid employees (Oracle 12c+)
SELECT * FROM employees
ORDER BY salary DESC
FETCH FIRST 3 ROWS ONLY;
