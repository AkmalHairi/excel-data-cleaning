
-- Create Table
CREATE TABLE employees (
  id NUMBER,
  name VARCHAR2(100),
  department VARCHAR2(50),
  salary NUMBER(10, 2),
  hire_date DATE
);

-- Insert Sample Data
INSERT INTO employees (id, name, department, salary, hire_date) VALUES
(1, 'Ali Bin Ahmad', 'Finance', 4500.00, TO_DATE('2019-03-15', 'YYYY-MM-DD'));

INSERT INTO employees (id, name, department, salary, hire_date) VALUES
(2, 'Siti Aisyah', 'HR', 3800.00, TO_DATE('2021-06-01', 'YYYY-MM-DD'));

INSERT INTO employees (id, name, department, salary, hire_date) VALUES
(3, 'John Lim', 'IT', 5200.00, TO_DATE('2020-11-20', 'YYYY-MM-DD'));

INSERT INTO employees (id, name, department, salary, hire_date) VALUES
(4, 'Nurul Izzah', 'Finance', 4700.00, TO_DATE('2022-01-10', 'YYYY-MM-DD'));

INSERT INTO employees (id, name, department, salary, hire_date) VALUES
(5, 'Raj Kumar', 'HR', 4100.00, TO_DATE('2018-08-05', 'YYYY-MM-DD'));
